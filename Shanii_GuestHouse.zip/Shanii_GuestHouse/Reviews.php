<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Reviews</title>

   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <style>
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      body {
         background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
         color: #333;
      }

      h2 {
         text-align: center;
         font-size: 2.8rem;
         margin: 50px 0 30px;
         color: #2c3e50;
         letter-spacing: 1px;
         font-weight: 700;
         text-shadow: 1px 1px #fff;
      }

      .reviews {
         padding: 50px 20px;
         background: #fff;
         border-top: 5px solid #ff4f57;
         border-radius: 10px;
         box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
      }

      .swiper {
         width: 100%;
         padding: 20px 0 60px;
      }

      .swiper-wrapper {
         display: flex;
         align-items: stretch;
      }

      .swiper-slide {
         background-color: #ffffff;
         border-radius: 15px;
         padding: 25px;
         box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
         transition: all 0.3s ease-in-out;
         display: flex;
         flex-direction: column;
         justify-content: flex-start;
         align-items: center;
         text-align: center;
      }

      .swiper-slide:hover {
         transform: translateY(-10px);
         box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
      }

      .swiper-slide img {
         width: 120px;
         height: 120px;
         object-fit: cover;
         border-radius: 50%;
         border: 4px solid #ff4f57;
         margin-bottom: 15px;
         transition: transform 0.3s ease-in-out;
      }

      .swiper-slide:hover img {
         transform: scale(1.1);
      }

      .swiper-slide h3 {
         font-size: 1.4rem;
         font-weight: bold;
         color: #222;
         margin-bottom: 10px;
      }

      .swiper-slide p {
         font-size: 1rem;
         line-height: 1.6;
         color: #555;
      }

      .swiper-pagination-bullet {
         background: #ccc;
         opacity: 0.6;
         transition: background 0.3s;
      }

      .swiper-pagination-bullet-active {
         background: #ff4f57;
         opacity: 1;
      }

      /* Footer */
      .footer {
         background-color: #333;
         color: white;
         padding: 30px 0;
         text-align: center;
         margin-top: 60px;
      }

      .footer .row {
         display: flex;
         justify-content: center;
         align-items: center;
      }

      .footer .box img {
         width: 40px;
         height: 40px;
         transition: transform 0.3s;
      }

      .footer .box img:hover {
         transform: scale(1.2);
      }

      .footer .box h2 {
         font-size: 1.1rem;
         color: #fff;
         margin-top: 8px;
      }

      /* Responsive */
      @media (max-width: 768px) {
         h2 {
            font-size: 2.2rem;
         }

         .swiper-slide {
            padding: 20px;
         }
      }
   </style>

</head>
<body>

<?php include 'components/user_header.php'; ?>

<section class="reviews" id="reviews">
   <h2>Guest Reviews</h2>
   <div class="swiper reviews-slider">
      <div class="swiper-wrapper">
         <div class="swiper-slide box">
            <img src="images/face2.jpeg" alt="">
            <h3>Sarah Johnson</h3>
            <p>Stayed at Shani Residence in Kandy, and it was great! Quiet location, clean and cozy rooms, and the staff were incredibly welcoming and helpful. Breakfast was simple but good. Perfect for a peaceful stay in Kandy.</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/face4.jpg" alt="">
            <h3>Daniel Hayes</h3>
            <p>Shani Residence is a wonderful, peaceful spot in Kandy. The rooms were clean and comfortable, and the staff made me feel right at home with their warm hospitality. A great choice for anyone seeking a relaxing stay close to the city's main attractions.</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/face5.jpg" alt="">
            <h3>Emily Rodriguez</h3>
            <p>Had a lovely stay at Shani Residence! The quiet location and comfortable, clean rooms made it perfect for relaxation. The staff were friendly and attentive, adding a personal touch to my experience. Highly recommended for a cozy stay in Kandy.</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/face1.jpeg" alt="">
            <h3>David Lee</h3>
            <p>Shani Residence was a great choice! The location is quiet yet close to the main spots in Kandy. The rooms were clean and cozy, and the staff made me feel very welcome. Perfect for a relaxing stay!</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/face6.jpg" alt="">
            <h3>Olivia Martinez</h3>
            <p>Shani Residence was an excellent choice for my stay! The location is peaceful, yet it's just a short walk to the main attractions in Kandy. The rooms were clean and comfortable, and the staff were incredibly friendly and welcoming. It was the perfect spot for a relaxing getaway!</p>
         </div>
         <div class="swiper-slide box">
            <img src="images/face3.jpg" alt="">
            <h3>Alexander Greene</h3>
            <p>I had a fantastic stay at Shani Residence! It’s in a quiet area yet close to Kandy’s main attractions. My room was clean and comfortable, and the staff were friendly and helpful. The breakfast had a great variety of options. I highly recommend Shani Residence for a cozy retreat in Kandy!</p>
         </div>
      </div>
      <div class="swiper-pagination"></div>
   </div>
</section>

<section class="footer">
   <div class="row">
      <div class="box">
         <center><a href="index.php" class="btn"><img src="images/homepage.png" alt=""></a></center>
         <center><h2>Home</h2></center>
      </div>
   </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<script src="js/script.js"></script>

<script>
   var swiper = new Swiper('.reviews-slider', {
      slidesPerView: 1,
      spaceBetween: 20,
      loop: true,
      autoplay: {
         delay: 2500,
         disableOnInteraction: false,
      },
      pagination: {
         el: '.swiper-pagination',
         clickable: true,
      },
      breakpoints: {
         640: {
            slidesPerView: 1,
         },
         768: {
            slidesPerView: 2,
         },
         1024: {
            slidesPerView: 3,
         },
      },
   });
</script>

</body>
</html>

