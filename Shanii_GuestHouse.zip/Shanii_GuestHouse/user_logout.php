<?php

include 'components/db_connect.php';

setcookie('user_id', '', time() - 1, '/');

header('location:user_login.php');

exit();

?>