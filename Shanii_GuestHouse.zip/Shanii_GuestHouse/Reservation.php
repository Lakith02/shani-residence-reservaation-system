<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
include 'components/db_connect.php';

if (isset($_COOKIE['user_id'])) {
    $user_id = $_COOKIE['user_id'];
} else {
    setcookie('user_id', create_unique_id(), time() + 60*60*24*30, '/');
    header('location:index.php');
    exit;
}

if (isset($_POST['book'])) {
    $booking_id = create_unique_id();
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
    $number = filter_var($_POST['number'], FILTER_SANITIZE_STRING);
    $rooms = filter_var($_POST['rooms'], FILTER_SANITIZE_STRING);
    $check_in = filter_var($_POST['check_in'], FILTER_SANITIZE_STRING);
    $check_out = filter_var($_POST['check_out'], FILTER_SANITIZE_STRING);
    $adults = filter_var($_POST['adults'], FILTER_SANITIZE_STRING);
    $childs = filter_var($_POST['childs'], FILTER_SANITIZE_STRING);

    $total_rooms = 0;
    $check_bookings = $conn->prepare("SELECT * FROM `bookings` WHERE check_in = ?");
    $check_bookings->execute([$check_in]);

    while ($row = $check_bookings->fetch(PDO::FETCH_ASSOC)) {
        $total_rooms += $row['rooms'];
    }

    if ($total_rooms >= 30) {
        $warning_msg[] = 'Rooms are not available';
    } else {
        $verify = $conn->prepare("SELECT * FROM `bookings` WHERE user_id = ? AND name = ? AND email = ? AND number = ? AND rooms = ? AND check_in = ? AND check_out = ? AND adults = ? AND childs = ?");
        $verify->execute([$user_id, $name, $email, $number, $rooms, $check_in, $check_out, $adults, $childs]);

        if ($verify->rowCount() > 0) {
            $warning_msg[] = 'Room already booked!';
        } else {
            $stmt = $conn->prepare("INSERT INTO `bookings`(booking_id, user_id, name, email, number, rooms, check_in, check_out, adults, childs) VALUES(?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$booking_id, $user_id, $name, $email, $number, $rooms, $check_in, $check_out, $adults, $childs]);

            $mail = new PHPMailer(true);
            try {
               $mail->isSMTP();
               $mail->Host = 'smtp.gmail.com'; 
               $mail->SMTPAuth = true;
               $mail->Username = 'nisalasandaruwan969@gmail.com'; 
               $mail->Password = 'kzck kcei xifh zuto'; 
               $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
               $mail->Port = 587;

               $mail->setFrom('nisalasandaruwan969@gmail.com', 'Deer Point Hotel');
               $mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Booking Confirmation';
                $mail->Body = "
                    <h2>Booking Confirmed!</h2>
                    <p><strong>Name:</strong> $name</p>
                    <p><strong>Rooms:</strong> $rooms</p>
                    <p><strong>Check-in:</strong> $check_in</p>
                    <p><strong>Check-out:</strong> $check_out</p>
                    <p><strong>Adults:</strong> $adults | <strong>Children:</strong> $childs</p>
                    <p>Thank you for booking with Shanii Guest House!</p>
                ";

                $mail->send();
                $success_msg[] = 'Booking successful! Confirmation email sent.';
            } catch (Exception $e) {
                $warning_msg[] = "Booking successful, but email could not be sent: {$mail->ErrorInfo}";
            }

            header('location:index.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Reservation</title>

   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <style>
      /* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    color: #333;
}

/* Header */
header {
    background: #333;
    padding: 10px;
    color: white;
    text-align: center;
}

/* Reservation Section */
.reservation {
   padding: 70px 20px;
   background: linear-gradient(to right, #f8f9fa, #ecf0f1);
   color: #2c3e50;
   font-family: 'Segoe UI', sans-serif;
}

.reservation .container {
   max-width: 1100px;
   margin: 0 auto;
}

.reservation-title {
   font-size: 2rem;
   margin-bottom: 10px;
   text-align: center;
}

.reservation-title span {
   color: #2980b9;
   font-weight: bold;
}

.reservation-subtitle {
   text-align: center;
   font-size: 1.1rem;
   margin-bottom: 40px;
   color: #555;
}

.reservation-form {
   background-color: #fff;
   padding: 30px;
   border-radius: 10px;
   box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

.form-grid {
   display: grid;
   grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
   gap: 20px;
}

.form-group {
   display: flex;
   flex-direction: column;
}

.form-group label {
   font-weight: bold;
   margin-bottom: 8px;
}

.form-group input,
.form-group select {
   padding: 12px;
   font-size: 1rem;
   border: 1px solid #ccc;
   border-radius: 6px;
   transition: border-color 0.3s;
}

.form-group input:focus,
.form-group select:focus {
   border-color: #3498db;
   outline: none;
}

.btn-submit {
   margin-top: 30px;
   padding: 15px 30px;
   font-size: 1.1rem;
   background-color: #3498db;
   color: white;
   border: none;
   border-radius: 8px;
   cursor: pointer;
   transition: background-color 0.3s ease;
}

.btn-submit:hover {
   background-color: #2980b9;
}

@media screen and (max-width: 768px) {
   .reservation-title {
      font-size: 1.5rem;
   }

   .reservation-form {
      padding: 20px;
   }

   .btn-submit {
      width: 100%;
   }
}

 </style>
</head>
<body>
<?php include 'components/user_header.php'; ?>

<section class="reservation" id="reservation">
   <div class="container">
      <h2 class="reservation-title">Welcome to Deer Point Hotel, <span><?php($_COOKIE['user_id']); ?>!</span></h2>
      <p class="reservation-subtitle">Complete your reservation details below and we'll take care of the rest.</p>

      <form action="" method="post" class="reservation-form">
         <div class="form-grid">

            <div class="form-group">
               <label>Your Name</label>
               <input type="text" name="name" required placeholder="e.g., John Doe">
            </div>

            <div class="form-group">
               <label>Email Address</label>
               <input type="email" name="email" required placeholder="e.g., john@example.com">
            </div>

            <div class="form-group">
               <label>Phone Number</label>
               <input type="tel" name="number" pattern="[0-9]{10,12}" required placeholder="e.g., 0712345678">
            </div>

            <div class="form-group">
               <label>Number of Rooms</label>
               <select name="rooms" required>
                  <option value="" disabled selected>Select rooms</option>
                  <option value="1">1 Room</option>
                  <option value="2">2 Rooms</option>
                  <option value="3">3 Rooms</option>
                  <option value="4">4 Rooms</option>
               </select>
            </div>

            <div class="form-group">
               <label>Check-in Date</label>
               <input type="date" name="check_in" required>
            </div>

            <div class="form-group">
               <label>Check-out Date</label>
               <input type="date" name="check_out" required>
            </div>

            <div class="form-group">
               <label>Adults</label>
               <select name="adults" required>
                  <option value="1">1 Adult</option>
                  <option value="2">2 Adults</option>
                  <option value="3">3 Adults</option>
                  <option value="4">4 Adults</option>
               </select>
            </div>

            <div class="form-group">
               <label>Children</label>
               <select name="childs" required>
                  <option value="0">No Children</option>
                  <option value="1">1 Child</option>
                  <option value="2">2 Children</option>
                  <option value="3">3 Children</option>
               </select>
            </div>

         </div>

         <div class="form-footer">
            <input type="submit" name="book" value="Book Now" class="btn-submit">
         </div>
      </form>
   </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script src="js/script.js"></script>

<section class="footer">
    <div class="row">
        <div class="box">
            <center><a href="index.php" class="btn"><img src="images/homepage.png" alt=""></a></center>
            <center><h2>Home</h2></center>
        </div>
    </div>
</section>

<?php include 'components/message.php'; ?>
</body>
</html>
