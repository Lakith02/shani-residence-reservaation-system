<?php 
if(isset($_POST['Signin'])){
    header('Location: user_login.php');
}
if(isset($_POST['Signup'])){
    header('Location: Register.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Signin/Signup</title>

   <style>
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      body {
         height: 100vh;
         display: flex;
         justify-content: center;
         align-items: center;
         background: linear-gradient(135deg, #2c3e50, #3498db);
         overflow: hidden;
      }

      .form-container {
         background: rgba(255, 255, 255, 0.1);
         backdrop-filter: blur(15px);
         border-radius: 15px;
         padding: 40px 30px;
         width: 90%;
         max-width: 400px;
         box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
         animation: fadeIn 1s ease-in-out;
      }

      .form-container h3 {
         text-align: center;
         font-size: 28px;
         margin-bottom: 30px;
         color: #fff;
         letter-spacing: 1px;
      }

      .form-container .btn {
         width: 100%;
         padding: 12px;
         margin: 10px 0;
         font-size: 16px;
         font-weight: bold;
         border: none;
         border-radius: 8px;
         background: #ffffff;
         color: #2c3e50;
         cursor: pointer;
         transition: all 0.3s ease;
         box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      }

      .form-container .btn:hover {
         background: #ffd700;
         color: #000;
         transform: translateY(-2px);
         box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
      }

      @keyframes fadeIn {
         from {
            opacity: 0;
            transform: scale(0.95);
         }
         to {
            opacity: 1;
            transform: scale(1);
         }
      }

      @media (max-width: 500px) {
         .form-container {
            padding: 30px 20px;
         }

         .form-container h3 {
            font-size: 22px;
         }

         .form-container .btn {
            font-size: 15px;
         }
      }
   </style>
</head>
<body>

<section class="form-container">
   <form action="" method="POST">
      <h3>Sign in / Sign up</h3>
      <input type="submit" value="Sign in" name="Signin" class="btn">
      <input type="submit" value="Sign up" name="Signup" class="btn">
   </form>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script src="../js/admin_script.js"></script>
<?php include 'components/message.php'; ?>

</body>
</html>
