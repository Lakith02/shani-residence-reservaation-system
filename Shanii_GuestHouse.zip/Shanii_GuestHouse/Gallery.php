<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Gallery - DEER POINT HOTEL</title>

   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <style>
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      body {
         background: linear-gradient(to right,rgb(1, 5, 14), #2a5298);
         color: #fff;
         min-height: 100vh;
         display: flex;
         flex-direction: column;
         align-items: center;
         justify-content: center;
         padding: 20px;
      }

      h1 {
         font-size: 2.8rem;
         text-align: center;
         margin-bottom: 30px;
         color: #f1c40f;
         text-shadow: 2px 2px 5px rgba(0,0,0,0.5);
      }

      .gallery {
         width: 100%;
         max-width: 1200px;
         margin: auto;
      }

      .swiper {
         width: 100%;
         height: 500px;
         border-radius: 15px;
         overflow: hidden;
         box-shadow: 0 10px 25px rgba(0,0,0,0.4);
      }

      .swiper-slide {
         display: flex;
         justify-content: center;
         align-items: center;
         transition: transform 0.4s ease;
         overflow: hidden;
         border-radius: 15px;
      }

      .swiper-slide img {
         width: 100%;
         height: 100%;
         object-fit: cover;
         border-radius: 15px;
         transition: transform 0.4s ease;
      }

      .swiper-slide:hover img {
         transform: scale(1.05);
         filter: brightness(110%);
      }

      .swiper-pagination-bullet {
         background: #f1c40f;
         opacity: 0.7;
      }

      .swiper-pagination-bullet-active {
         background: #fff;
         opacity: 1;
      }

      .footer {
         margin-top: 40px;
         text-align: center;
      }

      .footer .btn {
         display: inline-block;
         margin: 10px auto;
         background: #f1c40f;
         color: #000;
         padding: 12px 25px;
         text-decoration: none;
         font-weight: bold;
         border-radius: 30px;
         transition: all 0.3s ease;
         box-shadow: 0 0 10px #000;
      }

      .footer .btn:hover {
         background: #fff;
         color: #000;
         transform: scale(1.05);
         box-shadow: 0 0 15px #f1c40f;
      }

      .footer h2 {
         color: #fff;
         margin-top: 10px;
      }

      @media (max-width: 768px) {
         .swiper {
            height: 300px;
         }
         h1 {
            font-size: 2rem;
         }
      }
   </style>
</head>
<body>

   <?php include 'components/user_header.php'; ?>

   <h1>Explore Our Gallery</h1>

   <section class="gallery" id="gallery">
      <div class="swiper gallery-slider">
         <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="images/g2.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/g1.jpeg" alt=""></div>
            <div class="swiper-slide"><img src="images/view.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/g4.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/g3.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/home.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/g5.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/travel.jpg" alt=""></div>
         </div>
         <div class="swiper-pagination"></div>
      </div>
   </section>

   <section class="footer">
      <a href="index.php" class="btn"><i class="fas fa-home"></i> Back to Home</a>
      <h2>Deer Point Hotel</h2>
   </section>

   <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
   <script>
      const swiper = new Swiper('.gallery-slider', {
         loop: true,
         spaceBetween: 20,
         grabCursor: true,
         centeredSlides: true,
         autoplay: {
            delay: 3000,
            disableOnInteraction: false,
         },
         pagination: {
            el: '.swiper-pagination',
            clickable: true,
         },
         breakpoints: {
            0: {
               slidesPerView: 1,
            },
            768: {
               slidesPerView: 2,
            },
            1024: {
               slidesPerView: 3,
            }
         }
      });
   </script>

</body>
</html>
