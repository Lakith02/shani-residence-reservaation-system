<?php
include_once('components/db_connect.php');

if (isset($_POST['check'])) {
   $check_in = $_POST['check_in'];
   $check_in = filter_var($check_in, FILTER_SANITIZE_STRING);

   $total_rooms = 0;

   $check_bookings = $conn->prepare("SELECT * FROM `bookings` WHERE check_in = ?");
   $check_bookings->execute([$check_in]);

   while ($fetch_bookings = $check_bookings->fetch(PDO::FETCH_ASSOC)) {
      $total_rooms += $fetch_bookings['rooms'];
   }

   if ($total_rooms >= 30) {
      $warning_msg[] = 'rooms are not available';
   } else {
      $success_msg[] = 'rooms are available';
   }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Deer Point Hotel</title>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- Internal CSS -->
   <style>
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Arial', sans-serif;
      }

      body {
         background-color: #f7f7f7;
         color: #333;
      }

      a {
         text-decoration: none;
         color: inherit;
      }

      /* Header */
      header {
         background-color: #2C3E50;
         color: white;
         padding: 15px;
         text-align: center;
         font-size: 1.5rem;
      }

      /* Home Section */
      .home {
         position: relative;
         height: 100vh;
         background-color: #2C3E50;
         overflow: hidden;
      }

      .swiper-slide img {
         width: 100%;
         height: 100%;
         object-fit: cover;
         transition: transform 1s ease-in-out;
      }

      .swiper-slide:hover img {
         transform: scale(1.1);
      }

      .home .swiper-wrapper {
         display: flex;
      }

      .home .swiper-button-next,
      .home .swiper-button-prev {
         background-color: rgba(0, 0, 0, 0.5);
         color: #fff;
         border-radius: 50%;
         padding: 10px;
         z-index: 1;
      }

      .swiper-button-next {
         right: 20px;
      }

      .swiper-button-prev {
         left: 20px;
      }

      /* Availability Section */
    
.availability {
   padding: 50px 0;
   background-color: #fff;
   text-align: center;
}

.availability .box {
   display: inline-block;
   width: 20%;
   margin: 0 10px;
   background-color: #F1F1F1;
   padding: 20px;
   border-radius: 8px;
   box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
   transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

.availability .box:hover {
   background-color: #2C3E50;
   color: white;
   box-shadow: 0 10px 15px rgba(0, 0, 0, 0.15);
}

.availability p {
   font-size: 1rem;
   margin-bottom: 15px;
}

.availability input,
.availability select {
   width: 100%;
   padding: 12px;
   margin-top: 10px;
   border: 1px solid #ccc;
   border-radius: 8px;
   font-size: 1rem;
}

.availability .btn {
   background-color: #2C3E50;
   color: white;
   padding: 12px 20px; /* Reduced padding */
   border: none;
   border-radius: 5px;
   cursor: pointer;
   font-size: 1.1rem;
   margin-top: 20px;
   transition: background-color 0.3s ease;
   width: auto; /* Adjust button width to content */
}

.availability .btn:hover {
   background-color: #34495E;
}


     /* Services Section */
.services {
   padding: 60px 20px;
   background-color: #F5F5F5;
   text-align: center;
   box-shadow: inset 0 0 50px rgba(0, 0, 0, 0.1);
}

.services h2 {
   font-size: 2.5rem;
   color: #333;
   margin-bottom: 30px;
   font-weight: bold;
}

.services .box-container {
   display: flex;
   flex-wrap: wrap;
   justify-content: center;
   gap: 30px;
   margin-top: 20px;
}

.services .box {
   width: 280px;
   background-color: #ffffff;
   padding: 25px;
   border-radius: 12px;
   box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
   transition: all 0.3s ease-in-out;
   text-align: center;
   overflow: hidden;
   position: relative;
}

.services .box img {
   width: 70px;
   margin-bottom: 20px;
   transition: transform 0.3s ease-in-out;
}

.services .box h3 {
   font-size: 1.5rem;
   color: #2C3E50;
   font-weight: 600;
   margin-bottom: 15px;
   transition: color 0.3s ease;
}

.services .box p {
   font-size: 1rem;
   color: #555;
   line-height: 1.6;
   margin-bottom: 15px;
}

.services .box:hover {
   transform: translateY(-10px);
   box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
   background-color: #3498db;
}

.services .box:hover img {
   transform: scale(1.2);
}

.services .box:hover h3 {
   color: #fff;
}

.services .box:hover p {
   color: #f9f9f9;
}

.services .box .btn {
   padding: 10px 20px;
   border-radius: 30px;
   background-color: #fff;
   color: #3498db;
   font-size: 1rem;
   text-transform: uppercase;
   border: 2px solid #3498db;
   cursor: pointer;
   transition: background-color 0.3s ease, color 0.3s ease;
   margin-top: 20px;
}

.services .box .btn:hover {
   background-color: #3498db;
   color: #fff;
}

      /* Footer Section */
      footer {
         background-color: #2C3E50;
         color: white;
         text-align: center;
         padding: 15px;
         font-size: 1rem;
      }

      /* Media Queries for Responsiveness */
      @media (max-width: 768px) {
         .home {
            height: 80vh;
         }

         .availability .box {
            width: 45%;
         }

         .services .box-container {
            flex-direction: column;
         }

         .swiper-button-next,
         .swiper-button-prev {
            display: none;
         }
      }
   </style>
</head>

<body>

<?php include 'components/user_header.php'; ?>

<!-- Home Section -->
<section class="home" id="home">
   <div class="swiper home-slider">
      <div class="swiper-wrapper">
         <div class="swiper-slide">
            <img src="images/views.jpg" alt="Beautiful View">
            <div class="swiper-caption">
               <h3>Beautiful View</h3>
            </div>
         </div>
         <div class="swiper-slide">
            <img src="images/pexels-pixabay-237371.jpg" alt="Luxury Rooms">
            <div class="swiper-caption">
               <h3>Luxury Rooms</h3>
            </div>
         </div>
      </div>
      <!-- Swiper Navigation -->
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
   </div>
</section>

<!-- Availability Section -->
<section class="availability" id="availability">
   <form action="" method="post">
      <div class="box">
         <p>Check In</p>
         <input type="date" name="check_in" class="input" required>
      </div>
      <div class="box">
         <p>Check Out</p>
         <input type="date" name="check_out" class="input" required>
      </div>
      <div class="box">
         <p>Adults</p>
         <select name="adults" class="input" required>
            <option value="1">1 adult</option>
            <option value="2">2 adults</option>
            <option value="3">3 adults</option>
            <option value="4">4 adults</option>
            <option value="5">5 adults</option>
         </select>
      </div>
      <div class="box">
         <p>Rooms</p>
         <select name="rooms" class="input" required>
            <option value="1">1 room</option>
            <option value="2">2 rooms</option>
            <option value="3">3 rooms</option>
            <option value="4">4 rooms</option>
            <option value="5">5 rooms</option>
         </select>
      </div>
      <input type="submit" value="Check Availability" name="check" class="btn">
   </form>
</section>

<!-- Services Section -->
<section class="services">
   <div class="box-container">
      <div class="box">
         <img src="images/wifi.png" alt="Free Wifi">
         <h3>Free Wifi</h3>
         <p>Free WiFi keeps you connected and makes every moment more convenient. Enjoy seamless browsing wherever you are!</p>
      </div>

      <div class="box">
         <img src="images/icon-1.png" alt="Food & Drinks">
         <h3>Food & Drinks</h3>
         <p>Food and drinks bring us together and make every meal a celebration. Enjoy each bite and sip!</p>
      </div>

      <div class="box">
         <img src="images/icon-2.png" alt="Outdoor Dining">
         <h3>Outdoor Dining</h3>
         <p>Outdoor dining brings food, nature, and relaxation together. Enjoy fresh flavors and scenic views with every meal!</p>
      </div>

      <div class="box">
         <img src="images/icon-3.png" alt="Beautiful Sunshine">
         <h3>Beautiful Sunshine</h3>
         <p>Sunshine brightens any day, filling it with warmth and energy. Soak up the light and let it lift your spirits!</p>
      </div>

      <div class="box">
         <img src="images/icon-4.png" alt="Decorations">
         <h3>Decorations</h3>
         <p>Decorations transform spaces, adding charm and personality. Enjoy the ambiance and let every detail enhance your experience!</p>
      </div>

      <div class="box">
         <img src="images/icon-5.png" alt="Swimming Pool">
         <h3>Swimming Pool</h3>
         <p>A swimming pool offers the perfect escape—refreshing, relaxing, and fun. Dive in and let the water rejuvenate you!</p>
      </div>
   </div>
</section>

<!-- Footer Section -->
<footer>
   <p>&copy; 2025 Deer Point Hotel. All Rights Reserved.</p>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<script>
   const swiper = new Swiper('.home-slider', {
      loop: true,
      navigation: {
         nextEl: '.swiper-button-next',
         prevEl: '.swiper-button-prev',
      },
      autoplay: {
         delay: 5000,
         disableOnInteraction: false,
      },
      effect: 'fade',
      fadeEffect: {
         crossFade: true
      },
   });
</script>

</body>

</html>

