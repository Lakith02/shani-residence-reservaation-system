<?php

   $db_name = 'mysql:host=localhost;dbname=guest_house';
   $db_user_name = 'root';
   $db_user_pass = '';

   try {
      
      $conn = new PDO($db_name, $db_user_name, $db_user_pass);
      
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      echo "";
      
  } catch (PDOException $e) {
      
      die("Connection failed: " . $e->getMessage());
  }
   
   function create_unique_id(){
      $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      $rand = array();
      $length = strlen($str) - 1;

      for($i = 0; $i < 20; $i++){
         $n = random_int(0, $length);
         $rand[] = $str[$n];
      }
      return implode($rand);
   }

?>