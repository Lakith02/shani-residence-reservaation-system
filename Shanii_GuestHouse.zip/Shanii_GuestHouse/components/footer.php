<style>
.footer {
   background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
   color: #fff;
   padding: 3rem 1rem 1rem;
   font-family: 'Segoe UI', sans-serif;
}

.footer .box-container {
   display: grid;
   grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
   gap: 2rem;
   max-width: 1200px;
   margin: 0 auto;
   padding-bottom: 2rem;
}

.footer .box {
   display: flex;
   flex-direction: column;
   gap: 1rem;
}

.footer .box a {
   color: #f0f0f0;
   text-decoration: none;
   font-size: 1rem;
   transition: 0.3s ease;
   display: flex;
   align-items: center;
   gap: 10px;
}

.footer .box a:hover {
   color: #ffd369;
   transform: translateX(5px);
}

.footer .box a i {
   font-size: 1.1rem;
   transition: 0.3s ease;
}

.footer .box:nth-child(3) a {
   justify-content: flex-start;
   text-transform: capitalize;
}

.footer .box:nth-child(3) a:hover i {
   color: #ffd369;
   transform: scale(1.2);
}

.footer .credit {
   text-align: center;
   border-top: 1px solid rgba(255, 255, 255, 0.1);
   padding-top: 1rem;
   font-size: 0.9rem;
   color: #ccc;
   margin-top: 2rem;
}
</style>

<section class="footer">

   <div class="box-container">

      <div class="box">
         <a href="tel:0771612109"><i class="fas fa-phone"></i> +94 77 161 2109</a>
         <a href="tel:0718145990"><i class="fas fa-phone"></i> +94 71 814 5990</a>
         <a href="mailto:shaniiresidence@gmail.com"><i class="fas fa-envelope"></i> shaniiresidence@gmail.com</a>
         <a href="https://maps.app.goo.gl/KsofUQc3FZZHmgpk8"><i class="fas fa-map-marker-alt"></i> No.12 Reservoir Rd, Kandy 20000</a>
      </div>

      <div class="box">
         <a href="index.php">Home</a>
         <a href="About.php">About</a>
         <a href="Choose.php">Reservation</a>
         <a href="userlogin.php">My Booking</a>
         <a href="Gallery.php">Gallery</a>
         <a href="Contact.php">Contact</a>
         <a href="Reviews.php">Reviews</a>
      </div>

      <div class="box">
         <a href="#"><i class="fab fa-facebook-f"></i> Facebook</a>
         <a href="#"><i class="fab fa-twitter"></i> Twitter</a>
         <a href="#"><i class="fab fa-instagram"></i> Instagram</a>
         <a href="#"><i class="fab fa-youtube"></i> YouTube</a>
      </div>

   </div>

   <div class="credit">
      &copy; 2025 by <strong>Kandy NIBM</strong> | All rights reserved!
   </div>

</section>

