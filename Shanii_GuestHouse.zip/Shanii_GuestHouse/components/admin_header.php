<!-- Admin Panel Header Section -->
<header class="header">

   <section class="flex">

      <a href="dashboard.php" class="logo">AdminPanel</a>

      <nav class="navbar">
         <a href="dashboard.php">Home</a>
         <a href="bookings.php">Bookings</a>
         <a href="admins.php">Admins</a>
         <a href="messages.php">Messages</a>
         <a href="register.php">Register</a>
         <a href="login.php">Login</a>
         <a href="admin_logout.php" onclick="return confirm('logout from this website?');">Logout</a>
      </nav>

      <div id="menu-btn" class="fas fa-bars"></div>

   </section>

</header>

<!-- Font Awesome (Menu Icon Support) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

<style>
/* Base Reset */
* {
   margin: 0;
   padding: 0;
   box-sizing: border-box;
   font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Body Background for Preview */
body {
   background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
   color: #fff;
}

/* Header Base */
.header {
   position: sticky;
   top: 0;
   z-index: 1000;
   background: rgba(255, 255, 255, 0.05);
   backdrop-filter: blur(12px);
   box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
   border-bottom: 1px solid rgba(255, 255, 255, 0.1);
   padding: 1rem 2rem;
}

/* Flexbox Layout */
.header .flex {
   display: flex;
   align-items: center;
   justify-content: space-between;
   flex-wrap: wrap;
}

/* Logo */
.header .logo {
   font-size: 1.8rem;
   font-weight: bold;
   color: #ffcc00;
   text-decoration: none;
   text-shadow: 0 1px 4px rgba(0, 0, 0, 0.5);
   transition: color 0.3s;
}

.header .logo:hover {
   color: #ffffff;
}

/* Navigation Links */
.navbar {
   display: flex;
   gap: 1rem;
   flex-wrap: wrap;
}

.navbar a {
   color: #fff;
   text-decoration: none;
   padding: 0.6rem 1rem;
   border-radius: 8px;
   background: rgba(255, 255, 255, 0.08);
   transition: all 0.3s ease;
}

.navbar a:hover {
   background: #ffcc00;
   color: #2c3e50;
   box-shadow: 0 0 10px #ffcc00, 0 0 5px #fff;
   transform: scale(1.05);
}

/* Menu Icon (for mobile) */
#menu-btn {
   font-size: 1.8rem;
   color: #fff;
   cursor: pointer;
   display: none;
   transition: transform 0.3s ease;
}

#menu-btn:hover {
   transform: scale(1.2);
}

/* Responsive Navbar */
@media (max-width: 768px) {
   .navbar {
      display: none;
      flex-direction: column;
      align-items: flex-start;
      width: 100%;
      margin-top: 1rem;
      background: rgba(0, 0, 0, 0.4);
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding: 1rem;
      animation: fadeIn 0.3s ease-in-out;
   }

   .navbar.active {
      display: flex;
   }

   #menu-btn {
      display: block;
   }

   .navbar a {
      width: 100%;
      margin: 0.3rem 0;
   }
}

/* Fade-in animation */
@keyframes fadeIn {
   from {
      opacity: 0;
      transform: translateY(-10px);
   }
   to {
      opacity: 1;
      transform: translateY(0);
   }
}
</style>

<!-- Toggle Script -->
<script>
   let menuBtn = document.querySelector('#menu-btn');
   let navbar = document.querySelector('.navbar');

   menuBtn.onclick = () => {
      navbar.classList.toggle('active');
   };
</script>
