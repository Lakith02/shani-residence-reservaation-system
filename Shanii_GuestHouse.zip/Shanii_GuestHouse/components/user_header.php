<!-- Header Section with Advanced Glassmorphism Styling -->
<section class="header">
   <div class="flex">
      <a href="index.php" class="logo">DEER POINT HOTEL</a>
      <div id="menu-btn" class="fas fa-bars"></div>
      <nav class="navbarlg">
         <a href="user_login.php">Sign in</a>
         <a href="Register.php">Sign up</a>
         <a href="user_logout.php">Log out</a>
      </nav>
   </div>

   <nav class="navbar">
      <a href="index.php">Home</a>
      <a href="About.php">About</a>
      <a href="Choose.php">Reservation</a>
      <a href="Mybooking.php">My Booking</a>
      <a href="Gallery.php">Gallery</a>
      <a href="Contact.php">Contact Us</a>
      <a href="Reviews.php">Reviews</a>
   </nav>
</section>

<!-- Font Awesome (for icons like menu button) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

<style>
/* Reset */
* {
   margin: 0;
   padding: 0;
   box-sizing: border-box;
   font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
   background: linear-gradient(135deg, #212928, #2c3e50);
   color: #fff;
   min-height: 100vh;
}

/* Header Styling */
.header {
   position: sticky;
   top: 0;
   z-index: 1000;
   background: rgba(255, 255, 255, 0.05);
   backdrop-filter: blur(12px);
   box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
   padding: 15px 25px;
   border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

/* Flex Container */
.header .flex {
   display: flex;
   justify-content: space-between;
   align-items: center;
   flex-wrap: wrap;
}

/* Logo */
.header .logo {
   font-size: 1.8rem;
   color: #ffeb3b;
   font-weight: bold;
   text-decoration: none;
   text-shadow: 1px 1px 3px rgba(0,0,0,0.6);
}

.header .logo:hover {
   color: #ffffff;
}

/* Top Right Auth Nav */
.navbarlg {
   display: flex;
   gap: 1rem;
}

.navbarlg a {
   color: #fff;
   text-decoration: none;
   padding: 6px 12px;
   border-radius: 6px;
   transition: 0.3s ease;
   background: rgba(255, 255, 255, 0.05);
}

.navbarlg a:hover {
   background: #ffeb3b;
   color: #2c3e50;
   transform: scale(1.05);
}

/* Main Navigation Links */
.navbar {
   display: flex;
   justify-content: center;
   flex-wrap: wrap;
   gap: 1.2rem;
   margin-top: 10px;
   padding-bottom: 10px;
}

.navbar a {
   color: #fff;
   font-size: 1rem;
   text-decoration: none;
   padding: 10px 16px;
   border-radius: 20px;
   background: rgba(255, 255, 255, 0.08);
   transition: all 0.3s ease;
   box-shadow: inset 0 0 5px rgba(255,255,255,0.1);
}

.navbar a:hover {
   background: #ffeb3b;
   color: #2c3e50;
   box-shadow: 0 0 15px #fff, 0 0 5px #ffeb3b;
   transform: scale(1.05);
}

/* Menu Button for Mobile */
#menu-btn {
   display: none;
   font-size: 1.8rem;
   color: #fff;
   cursor: pointer;
   transition: 0.3s;
}

#menu-btn:hover {
   transform: scale(1.1);
}

/* Responsive Nav */
@media (max-width: 768px) {
   .navbar {
      display: none;
      flex-direction: column;
      align-items: center;
      background: rgba(0,0,0,0.3);
      border-top: 1px solid rgba(255,255,255,0.1);
      padding: 1rem 0;
      width: 100%;
      animation: fadeDown 0.4s ease-in-out;
   }

   .navbar.active {
      display: flex;
   }

   #menu-btn {
      display: block;
   }

   .navbarlg {
      flex-direction: column;
      align-items: flex-end;
      margin-top: 10px;
   }
}

/* Fade Down Animation */
@keyframes fadeDown {
   from {
      opacity: 0;
      transform: translateY(-10px);
   }
   to {
      opacity: 1;
      transform: translateY(0);
   }
}
</style>

<!-- Menu Toggle Script -->
<script>
   let menuBtn = document.querySelector('#menu-btn');
   let navbar = document.querySelector('.navbar');

   menuBtn.onclick = () => {
      navbar.classList.toggle('active');
   };
</script>



