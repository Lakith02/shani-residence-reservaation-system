<?php

include 'components/db_connect.php';

if (isset($_COOKIE['user_id'])) {
   $user_id = $_COOKIE['user_id'];
} else {
   setcookie('user_id', create_unique_id(), time() + 60 * 60 * 24 * 30, '/');
   header('location:index.php');
   exit;
}

if (isset($_POST['cancel'])) {

   $booking_id = $_POST['booking_id'];
   $booking_id = filter_var($booking_id, FILTER_SANITIZE_STRING);

   $verify_booking = $conn->prepare("SELECT * FROM bookings WHERE booking_id = ? AND user_id = ?");
   $verify_booking->execute([$booking_id, $user_id]);

   if ($verify_booking->rowCount() > 0) {
      $delete_booking = $conn->prepare("DELETE FROM bookings WHERE booking_id = ?");
      $delete_booking->execute([$booking_id]);
      $success_msg[] = 'Booking cancelled successfully!';
   } else {
      $warning_msg[] = 'Booking cancelled already!';
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>My Bookings</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

   <style>
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      body {
         background: #f2f2f2;
         padding: 2rem;
      }

      .heading {
         text-align: center;
         font-size: 2.5rem;
         color: #333;
         margin-bottom: 2rem;
         text-transform: uppercase;
         letter-spacing: 1px;
      }

      .bookings .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
         gap: 1.5rem;
      }

      .bookings .box {
         background: #fff;
         border-radius: 12px;
         padding: 20px;
         box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
         transition: transform 0.3s ease, box-shadow 0.3s ease;
         border-left: 5px solid #f857a6;
      }

      .bookings .box:hover {
         transform: translateY(-5px);
         box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
      }

      .bookings .box p {
         font-size: 1rem;
         margin: 0.5rem 0;
         color: #555;
      }

      .bookings .box span {
         font-weight: bold;
         color: #222;
      }

      .bookings .btn {
         margin-top: 1rem;
         display: inline-block;
         background: linear-gradient(to right, #f857a6, #ff5858);
         color: #fff;
         padding: 10px 20px;
         border-radius: 30px;
         border: none;
         cursor: pointer;
         text-transform: capitalize;
         font-size: 1rem;
         transition: background 0.3s ease;
      }

      .bookings .btn:hover {
         background: linear-gradient(to left, #f857a6, #ff5858);
         transform: scale(1.05);
      }

      @media (max-width: 500px) {
         .bookings .box {
            padding: 15px;
         }

         .heading {
            font-size: 2rem;
         }
      }
   </style>
</head>
<body>

<?php include 'components/user_header.php'; ?>

<section class="bookings">
   <h1 class="heading">My Bookings</h1>

   <div class="box-container">
      <?php
         $select_bookings = $conn->prepare("SELECT * FROM bookings WHERE user_id =?");
         $select_bookings->execute([$user_id]);
         if ($select_bookings->rowCount() > 0) {
            while ($fetch_booking = $select_bookings->fetch(PDO::FETCH_ASSOC)) {
      ?>
      <div class="box">
         <p>Name : <span><?= htmlspecialchars($fetch_booking['name']); ?></span></p>
         <p>Email : <span><?= htmlspecialchars($fetch_booking['email']); ?></span></p>
         <p>Number : <span><?= htmlspecialchars($fetch_booking['number']); ?></span></p>
         <p>Check In : <span><?= htmlspecialchars($fetch_booking['check_in']); ?></span></p>
         <p>Check Out : <span><?= htmlspecialchars($fetch_booking['check_out']); ?></span></p>
         <p>Rooms : <span><?= htmlspecialchars($fetch_booking['rooms']); ?></span></p>
         <p>Adults : <span><?= htmlspecialchars($fetch_booking['adults']); ?></span></p>
         <p>Childs : <span><?= htmlspecialchars($fetch_booking['childs']); ?></span></p>
         <p>Booking Id : <span><?= htmlspecialchars($fetch_booking['booking_id']); ?></span></p>
         <form action="" method="POST">
            <input type="hidden" name="booking_id" value="<?= htmlspecialchars($fetch_booking['booking_id']); ?>">
            <input type="submit" value="cancel booking" name="cancel" class="btn" onclick="return confirm('Cancel this booking?');">
         </form>
      </div>
      <?php
            }
         } else {
      ?>
      <div class="box" style="text-align: center;">
         <p style="padding-bottom: .5rem; text-transform: capitalize;">No bookings found!</p>
         <a href="Reservation.php" class="btn">Book New</a>
      </div>
      <?php
         }
      ?>
   </div>
</section>

<?php include 'components/message.php'; ?>

<?php if (!empty($success_msg)) {
   foreach ($success_msg as $msg) {
      echo "<script>swal('Success!', '".htmlspecialchars($msg, ENT_QUOTES)."', 'success');</script>";
   }
}
if (!empty($warning_msg)) {
   foreach ($warning_msg as $msg) {
      echo "<script>swal('Warning!', '".htmlspecialchars($msg, ENT_QUOTES)."', 'warning');</script>";
   }
} ?>

</body>
</html>
