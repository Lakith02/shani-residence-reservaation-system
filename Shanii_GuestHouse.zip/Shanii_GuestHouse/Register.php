<?php

include_once('components/db_connect.php');

if(isset($_POST['submit'])){

   $user_id = create_unique_id();
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING); 
   $pass = sha1($_POST['pass']);
   $c_pass = sha1($_POST['c_pass']);  

   $select_users = $conn->prepare("SELECT * FROM `users` WHERE name = ?");
   $select_users->execute([$name]);

   if($select_users->rowCount() > 0){
      $warning_msg[] = 'Username already taken!';
   }else{
      if($pass != $c_pass){
         $warning_msg[] = 'Password not matched!';
      }else{
         
         $insert_users = $conn->prepare("INSERT INTO `users` (id, name, password) VALUES(?,?,?)");
         $insert_users->execute([$user_id, $name, $pass]); 
         $success_msg[] = 'Registered successfully!';
         header('location:user_login.php');

      }
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">

   <style>
      /* Global Styles */
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Arial', sans-serif;
      }

      body {
         background-color: #f4f4f4;
         color: #333;
      }

      /* Form Container */
      .form-container {
         max-width: 400px;
         margin: 80px auto;
         background-color: #fff;
         padding: 30px;
         border-radius: 8px;
         box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
         text-align: center;
         animation: fadeIn 1s ease-in-out;
      }

      .form-container h3 {
         font-size: 1.8rem;
         color: #2C3E50;
         margin-bottom: 20px;
      }

      /* Input Styles */
      .box {
         width: 100%;
         padding: 12px;
         margin: 10px 0;
         border-radius: 5px;
         border: 1px solid #ccc;
         font-size: 1rem;
         transition: border-color 0.3s ease;
      }

      .box:focus {
         border-color: #3498db;
         outline: none;
      }

      .btn {
         background-color: #2C3E50;
         color: white;
         border: none;
         padding: 12px 20px;
         font-size: 1rem;
         cursor: pointer;
         border-radius: 5px;
         width: 100%;
         transition: background-color 0.3s ease;
      }

      .btn:hover {
         background-color: #34495E;
      }

      /* Password Strength Indicator */
      .password-strength {
         display: flex;
         justify-content: space-between;
         margin-top: 10px;
         font-size: 0.9rem;
      }

      .password-strength span {
         color: #e74c3c;
         font-weight: bold;
      }

      /* Success/Warning Messages */
      .success-msg, .warning-msg {
         margin-top: 15px;
         font-size: 1rem;
         text-align: center;
      }

      .success-msg {
         color: #27ae60;
      }

      .warning-msg {
         color: #e74c3c;
      }

      /* Animations */
      @keyframes fadeIn {
         0% {
            opacity: 0;
         }
         100% {
            opacity: 1;
         }
      }

      /* Media Queries for Mobile */
      @media (max-width: 768px) {
         .form-container {
            width: 80%;
         }

         .box, .btn {
            font-size: 0.9rem;
         }
      }
   </style>

</head>
<body>

<section class="form-container">
   <form action="" method="POST">
      <h3>Sign Up</h3>

      <!-- Username Input -->
      <input type="text" name="name" placeholder="Enter username" maxlength="20" class="box" required oninput="this.value = this.value.replace(/\s/g, '')">

      <!-- Password Input -->
      <input type="password" name="pass" placeholder="Enter password" maxlength="20" class="box" required oninput="checkPasswordStrength(this.value)">
      
      <!-- Confirm Password Input -->
      <input type="password" name="c_pass" placeholder="Confirm password" maxlength="20" class="box" required oninput="checkPasswordMatch()">

      <!-- Password Strength Indicator -->
      <div class="password-strength" id="passwordStrength">
         <span>Strength:</span>
         <span id="strengthText">Weak</span>
      </div>

      <!-- Submit Button -->
      <input type="submit" value="Register Now" name="submit" class="btn">

      <!-- Success/Warning Messages -->
      <?php if(isset($success_msg)): ?>
         <div class="success-msg"><?= implode('<br>', $success_msg); ?></div>
      <?php endif; ?>
      <?php if(isset($warning_msg)): ?>
         <div class="warning-msg"><?= implode('<br>', $warning_msg); ?></div>
      <?php endif; ?>

   </form>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<script>
   // Password Strength Checker
   function checkPasswordStrength(password) {
      const strengthBar = document.getElementById("passwordStrength");
      const strengthText = document.getElementById("strengthText");
      let strength = "Weak";
      let score = 0;

      if(password.length >= 6) {
         score += 1;
         if(password.match(/[a-z]/)) score += 1;
         if(password.match(/[A-Z]/)) score += 1;
         if(password.match(/\d/)) score += 1;
         if(password.match(/[@$!%*?&]/)) score += 1;
      }

      if(score <= 2) {
         strength = "Weak";
         strengthText.style.color = "#e74c3c";
      } else if(score <= 3) {
         strength = "Medium";
         strengthText.style.color = "#f39c12";
      } else {
         strength = "Strong";
         strengthText.style.color = "#27ae60";
      }

      strengthText.textContent = strength;
   }

   // Confirm Password Match Checker
   function checkPasswordMatch() {
      const password = document.querySelector('input[name="pass"]').value;
      const confirmPassword = document.querySelector('input[name="c_pass"]').value;

      if(password !== confirmPassword) {
         document.querySelector('input[name="c_pass"]').style.borderColor = "#e74c3c";
      } else {
         document.querySelector('input[name="c_pass"]').style.borderColor = "#2ecc71";
      }
   }
</script>

</body>
</html>
