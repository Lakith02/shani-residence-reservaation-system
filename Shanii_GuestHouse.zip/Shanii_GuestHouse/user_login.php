<?php
include_once('components/db_connect.php');

if (isset($_POST['submit'])) {

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING); 
   $pass = sha1($_POST['pass']);  
   
   $select_users = $conn->prepare("SELECT * FROM `users` WHERE name = ? AND password = ? LIMIT 1");    
   $select_users->execute([$name, $pass]);
   $row = $select_users->fetch(PDO::FETCH_ASSOC);

   if ($select_users->rowCount() > 0) {
       setcookie('user_id', $row['id'], time() + 60*60*24*30, '/');
       header('location:Reservation.php');
   } else {
       $warning_msg[] = 'Incorrect username or password!';
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

   <style>
      * {
         box-sizing: border-box;
         margin: 0;
         padding: 0;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      body {
         background: linear-gradient(135deg, #ff5858, #f857a6);
         display: flex;
         align-items: center;
         justify-content: center;
         min-height: 100vh;
      }

      .form-container {
         background: #fff;
         padding: 3rem 2.5rem;
         border-radius: 15px;
         box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
         max-width: 400px;
         width: 100%;
         animation: slideIn 0.6s ease-out;
      }

      @keyframes slideIn {
         from {
            transform: translateY(-30px);
            opacity: 0;
         }
         to {
            transform: translateY(0);
            opacity: 1;
         }
      }

      .form-container h3 {
         text-align: center;
         font-size: 2rem;
         color: #333;
         margin-bottom: 2rem;
      }

      .box {
         width: 100%;
         padding: 12px 15px;
         border: 1px solid #ccc;
         margin-bottom: 1.5rem;
         border-radius: 10px;
         outline: none;
         font-size: 1rem;
         transition: 0.3s;
         background: #f9f9f9;
      }

      .box:focus {
         border-color: #f857a6;
         background: #fff;
         box-shadow: 0 0 5px rgba(248, 87, 166, 0.4);
      }

      .btn {
         width: 100%;
         background: linear-gradient(to right, #ff5858, #f857a6);
         color: #fff;
         border: none;
         padding: 12px;
         border-radius: 50px;
         font-size: 1.1rem;
         cursor: pointer;
         transition: 0.4s;
      }

      .btn:hover {
         background: linear-gradient(to left, #ff5858, #f857a6);
         transform: scale(1.05);
      }

      .toggle-password {
         display: flex;
         align-items: center;
         gap: 0.5rem;
         margin-top: -1rem;
         margin-bottom: 1.5rem;
         font-size: 0.95rem;
         color: #666;
      }

      .toggle-password input[type="checkbox"] {
         transform: scale(1.2);
         cursor: pointer;
      }

      .toggle-password label {
         cursor: pointer;
      }
   </style>
</head>
<body>

<section class="form-container">
   <form action="" method="POST">
      <h3>Sign in</h3>

      <input type="text" name="name" placeholder="Enter username" maxlength="20" class="box" required oninput="this.value = this.value.replace(/\s/g, '')">

      <input type="password" name="pass" id="password" placeholder="Enter password" maxlength="20" class="box" required oninput="this.value = this.value.replace(/\s/g, '')">

      <div class="toggle-password">
         <input type="checkbox" id="showPass" onclick="togglePassword()">
         <label for="showPass">Show password</label>
      </div>

      <input type="submit" value="Login" name="submit" class="btn">
   </form>
</section>

<script>
function togglePassword() {
   const passField = document.getElementById("password");
   passField.type = passField.type === "password" ? "text" : "password";
}
</script>

<?php include 'components/message.php'; ?>

<?php if (!empty($warning_msg)) {
   foreach ($warning_msg as $msg) {
      echo "<script>swal('Oops!', '".htmlspecialchars($msg, ENT_QUOTES)."', 'warning');</script>";
   }
} ?>

</body>
</html>
