<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About - Deer Point Hotel</title>

   <style>
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      body {
         background: #f4f4f4;
         color: #333;
         line-height: 1.6;
      }

      .about {
         padding: 60px 20px;
         max-width: 1200px;
         margin: auto;
      }

      .row {
         display: flex;
         flex-wrap: wrap;
         align-items: center;
         margin-bottom: 80px;
         gap: 40px;
      }

      .revers {
         flex-direction: row-reverse;
      }

      .image {
         flex: 1 1 45%;
         border-radius: 15px;
         overflow: hidden;
         box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
      }

      .image img {
         width: 100%;
         height: auto;
         transition: transform 0.4s ease;
         border-radius: 15px;
      }

      .image img:hover {
         transform: scale(1.05);
      }

      .content {
         flex: 1 1 50%;
         background: #fff;
         padding: 30px;
         border-radius: 15px;
         box-shadow: 0 8px 16px rgba(0,0,0,0.1);
         transition: transform 0.3s ease;
      }

      .content:hover {
         transform: translateY(-5px);
      }

      .content h3 {
         font-size: 28px;
         color: #1e2a38;
         margin-bottom: 20px;
      }

      .content p {
         font-size: 16px;
         color: #555;
         text-align: justify;
      }

      .footer {
         background: #1e2a38;
         padding: 40px 20px;
         color: #fff;
         text-align: center;
      }

      .footer .box {
         max-width: 300px;
         margin: auto;
      }

      .footer .btn {
         display: inline-block;
         padding: 12px 20px;
         background: #fff;
         color: #1e2a38;
         text-decoration: none;
         border-radius: 8px;
         transition: background 0.3s ease, transform 0.3s ease;
      }

      .footer .btn:hover {
         background: #ffd700;
         transform: translateY(-3px);
      }

      .footer h2 {
         margin-top: 10px;
         font-size: 22px;
         font-weight: 500;
      }

      @media (max-width: 768px) {
         .row {
            flex-direction: column;
         }

         .content h3 {
            font-size: 22px;
         }

         .content p {
            font-size: 15px;
         }
      }
   </style>
</head>
<body>

<?php include 'components/user_header.php'; ?>

<section class="about" id="about">
   <div class="row">
      <div class="image">
         <img src="images/a.jpg" alt="Staff Photo">
      </div>
      <div class="content">
         <h3>Our Exceptional Staff:<br><br> Your Comfort is Our Priority</h3>
         <p>At our deer point hotel, our dedicated team goes above and beyond to make each guest’s stay unforgettable. With warm smiles and a passion for hospitality, our staff ensures that you feel at home from the moment you arrive. Each team member is highly trained, attentive, and committed to providing excellent service. Whether assisting with special requests, offering local recommendations, or ensuring your room is perfectly prepared, our staff takes pride in creating a welcoming, comfortable environment. Here, your comfort and satisfaction are our top priorities, and we look forward to making your stay as enjoyable as possible.</p>
      </div>
   </div>

   <div class="row revers">
      <div class="image">
         <img src="images/b.jpg" alt="Integrity">
      </div>
      <div class="content">
         <h3>Integrity and Trust:<br><br> Our Core Values</h3>
         <p>At our deer point hotel, integrity and trust are at the heart of everything we do. We believe that a strong foundation of honesty and transparency is essential for building lasting relationships with our guests. Our commitment to ethical practices ensures that you can have confidence in every aspect of your stay, from the quality of our services to the accuracy of our information. We strive to provide a welcoming atmosphere where you can relax and feel secure, knowing that your needs and preferences are respected. Our team is dedicated to upholding these values in all interactions, ensuring that your experience is not only pleasant but also reliable. We aim to exceed your expectations and earn your trust through consistent quality and genuine care.</p>
      </div>
   </div>
</section>

<section class="footer">
   <div class="row">
      <div class="box">
         <a href="index.php" class="btn"><img src="images/homepage.png" alt="Home Icon" width="24"></a>
         <h2>Home</h2>
      </div>
   </div>
</section>

</body>
</html>
