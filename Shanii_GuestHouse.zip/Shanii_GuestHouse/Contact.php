<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Contact Page</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <style>
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      body {
         background: linear-gradient(135deg, rgb(33, 41, 40), #2c3e50);
         color: #ffffff;
         min-height: 100vh;
         padding-top: 80px; /* space for fixed header */
      }

      header {
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         background: rgba(255, 255, 255, 0.08);
         backdrop-filter: blur(10px);
         box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
         z-index: 1000;
         display: flex;
         justify-content: space-between;
         align-items: center;
         padding: 15px 30px;
      }

      header .logo {
         font-size: 22px;
         color: #ffeb3b;
         font-weight: bold;
         text-transform: uppercase;
         letter-spacing: 1.2px;
         text-shadow: 1px 1px 2px #000;
      }

      header nav a {
         color: #ffffff;
         margin-left: 20px;
         font-size: 16px;
         text-decoration: none;
         transition: 0.3s;
      }

      header nav a:hover {
         color: #ffeb3b;
         text-shadow: 0 0 5px #ffeb3b;
      }

      .container {
         display: flex;
         justify-content: center;
         align-items: center;
         flex-direction: column;
         padding: 40px 20px;
      }

      .contact {
         background: rgba(255, 255, 255, 0.1);
         backdrop-filter: blur(12px);
         padding: 40px;
         border-radius: 20px;
         width: 100%;
         max-width: 1000px;
         box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
      }

      .contact h3 {
         text-align: center;
         font-size: 32px;
         margin-bottom: 25px;
         color: #fffae5;
         text-shadow: 1px 1px 3px rgba(0,0,0,0.6);
      }

      form {
         display: flex;
         flex-direction: column;
         gap: 18px;
         margin-bottom: 50px;
      }

      .box {
         background: rgba(255, 255, 255, 0.08);
         border: 2px solid #ffffff50;
         padding: 14px 18px;
         color: #fdfdfd;
         font-size: 16px;
         border-radius: 10px;
         transition: all 0.3s ease;
         box-shadow: inset 0 0 5px rgba(255,255,255,0.1);
      }

      .box::placeholder {
         color: #e0e0e0;
      }

      .box:focus {
         border-color: #ffeb3b;
         background-color: rgba(255, 255, 255, 0.12);
         box-shadow: 0 0 10px #ffeb3b70;
         outline: none;
      }

      textarea.box {
         resize: none;
         height: 120px;
      }

      .btn {
         background: #ffeb3b;
         color: #2c3e50;
         border: none;
         padding: 14px;
         font-weight: bold;
         font-size: 17px;
         border-radius: 10px;
         cursor: pointer;
         transition: all 0.3s;
         box-shadow: 0 5px 15px rgba(255, 235, 59, 0.4);
      }

      .btn:hover {
         background-color: #ffffff;
         color: #2c3e50;
         box-shadow: 0 0 15px #fff, 0 0 5px #ffeb3b;
         transform: scale(1.03);
      }

      .faq {
         margin-top: 30px;
      }

      .faq .title {
         text-align: center;
         font-size: 26px;
         margin-bottom: 25px;
         color: #fff9c4;
         text-transform: uppercase;
         letter-spacing: 1.2px;
      }

      .faq .box {
         background: rgba(255, 255, 255, 0.08);
         border-left: 5px solid #ffeb3b;
         padding: 18px;
         margin-bottom: 18px;
         border-radius: 12px;
         cursor: pointer;
         transition: background 0.3s;
         color: #f0f0f0;
      }

      .faq .box:hover {
         background: rgba(255, 255, 255, 0.15);
      }

      .faq .box h3 {
         font-size: 20px;
         margin-bottom: 10px;
         color: #ffeb3b;
         text-shadow: 1px 1px 2px rgba(0,0,0,0.4);
      }

      .faq .box p {
         font-size: 15px;
         color:rgb(20, 17, 17);
         line-height: 1.6;
      }

      @media(max-width: 768px) {
         header {
            flex-direction: column;
            align-items: flex-start;
            padding: 15px;
         }

         header nav {
            margin-top: 10px;
         }

         .contact {
            padding: 25px 18px;
         }

         .faq .title {
            font-size: 22px;
         }

         form {
            gap: 12px;
         }
      }
   </style>
</head>
<body>

<header>
   <div class="logo">Deer Point Hotel</div>
   <nav>
      <a href="index.php">Home</a>
      <a href="about.php">About</a>
      <a href="choose.php">Reservation</a>
      <a href="gallery.php">Gallery</a>
      <a href="contact.php">Contact</a>
   </nav>
</header>

<div class="container">

   <section class="contact">
      <h3>Contact Us</h3>
      <form action="#" method="post">
         <input type="text" class="box" placeholder="Your Name" required>
         <input type="email" class="box" placeholder="Your Email" required>
         <input type="text" class="box" placeholder="Subject">
         <textarea class="box" placeholder="Your Message" required></textarea>
         <button type="submit" class="btn">Send Message</button>
      </form>
   </section>

   <section class="faq">
      <h3 class="title">Frequently Asked Questions</h3>
      <div class="box">
         <h3>What is the check-in time?</h3>
         <p>Check-in time is from 2:00 PM. Early check-in is subject to availability.</p>
      </div>
      <div class="box">
         <h3>Do you offer free Wi-Fi?</h3>
         <p>Yes, high-speed Wi-Fi is available throughout the hotel free of charge.</p>
      </div>
      <div class="box">
         <h3>Is there parking available?</h3>
         <p>Yes, we offer free private parking for all guests.</p>
      </div>
   </section>

</div>

</body>
</html>
